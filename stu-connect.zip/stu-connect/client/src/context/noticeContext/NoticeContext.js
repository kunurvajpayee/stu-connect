import { createContext } from "react"

export const NoticeContext = createContext()
