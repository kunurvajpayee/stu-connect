const { createContext } = require("react")

export const UserContext = createContext()
