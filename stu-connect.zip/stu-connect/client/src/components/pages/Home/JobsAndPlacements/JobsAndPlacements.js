import React from "react"
import { Home } from "../../../common/Base/Home"

export const JobsAndPlacements = () => {
  return <Home></Home>
}
