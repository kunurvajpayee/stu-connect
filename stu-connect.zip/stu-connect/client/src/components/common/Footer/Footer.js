import React from "react"

export const Footer = () => {
  return <div>Copyrights @ 2020</div>
}
