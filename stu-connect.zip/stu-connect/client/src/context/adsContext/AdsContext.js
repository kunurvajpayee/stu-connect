import { createContext } from "react"

export const AdsContext = createContext()
